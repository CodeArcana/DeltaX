﻿using DeltaX.MoviePortal.Common;
using DeltaX.MoviePortal.Common.Entities;
using DeltaX.MoviePortal.DAL;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeltaX.MoviePortal.Test
{
    [TestClass]
    public class MoviePortalRepositoryTest
    {
        //[TestInitialize]
        //public void Initialize()
        //{
        //    Utility.SeedDatabase();
        //}

        [TestMethod]
        public void CreateActorTest()
        {
            var actor = new Actor
            {
                Name = "Marlon Brando",
                DateOfBirth = new DateTime(1924, 04, 03),
                Bio = "Marlon Brando is widely considered the greatest movie actor of all time, rivaled only by the more theatrically oriented Laurence Olivier in terms of esteem. Unlike Olivier, who preferred the stage to the screen, Brando concentrated his talents on movies after bidding the Broadway stage adieu in 1949.",
                Sex = "Male"
            };

            IMoviePortalRepository movieRrepo = new MoviePortalRepository();




            actor = movieRrepo.CreateActor(actor);




            // Create new customer
            //using (IDataContextAsync context = new NorthwindContext())
            //using (IUnitOfWorkAsync unitOfWork = new UnitOfWork(context))
            //{
            //    IRepositoryAsync<Customer> customerRepository = new Repository<Customer>(context, unitOfWork);

            //    var customer = new Customer
            //    {
            //        CustomerID = "LLE37",
            //        CompanyName = "CBRE",
            //        ContactName = "Long Le",
            //        ContactTitle = "App/Dev Architect",
            //        Address = "11111 Sky Ranch",
            //        City = "Dallas",
            //        PostalCode = "75042",
            //        Country = "USA",
            //        Phone = "(222) 222-2222",
            //        Fax = "(333) 333-3333",
            //        ObjectState = ObjectState.Added,
            //    };

            //    customerRepository.Insert(customer);
            //    unitOfWork.SaveChanges();
            //}

            ////  Query for newly created customer by ID from a new context, to ensure it's not pulling from cache
            //using (IDataContextAsync context = new NorthwindContext())
            //using (IUnitOfWorkAsync unitOfWork = new UnitOfWork(context))
            //{
            //    IRepositoryAsync<Customer> customerRepository = new Repository<Customer>(context, unitOfWork);
            //    var customer = customerRepository.Find("LLE37");
            //    Assert.AreEqual(customer.CustomerID, "LLE37");
            //}
        }


        //public void CreateMovie()
        //{
        //    var movie = new Movie
        //    {
        //        Name = "Gone With the Wind",
        //        DateOfRelease = new DateTime(1940, 01, 17),
        //        Plot = "A manipulative woman and a roguish man conduct a turbulent romance during the American Civil War and Reconstruction periods."
        //    };

        //    var producer = new Producer
        //    {
        //        Name = "David O. Selznick",
        //        Sex = "Male",
        //        DateOfBirth = new DateTime(1892, 09, 12),
        //        Bio = "David O. Selznick was a son of the silent movie producer Lewis J. Selznick. David studied at Columbia University until his father lost his fortune in the 1920s. David started work as an MGM script reader, shortly followed by becoming an assistant to Harry Rapf. He left MGM to work at Paramount then RKO."
        //    };

        //    var actor1 = new Actor
        //    {
        //        Name = "Thomas Mitchell",
        //        DateOfBirth = new DateTime(1862, 07, 06),
        //        Bio = "Thomas Mitchell was one of the great American character actors, whose credits read like a list of the greatest films of the 20th century: Lost Horizon (1937); Stagecoach (1939); The Hunchback of Notre Dame (1939); Mr. Smith Goes to Washington (1939); Gone with the Wind (1939); It's a Wonderful Life (1946) and High Noon (1952).",
        //        Sex = "Male"
        //    };
        //    var actor2 = new Actor
        //    {
        //        Name = "Barbara O'Neil",
        //        DateOfBirth = new DateTime(1878, 11, 23),
        //        Bio = "Barbara O'Neil was born on July 17, 1910 in St. Louis, Missouri, USA. She was an actress, known for Gone with the Wind (1939), All This, and Heaven Too (1940) and Stella Dallas (1937). She was married to Joshua Logan. She died on September 3, 1980 in Cos Cob, Connecticut, USA.",
        //        Sex = "Female"
        //    };
        //    var actor3 = new Actor
        //    {
        //        Name = "Vivien Leigh",
        //        DateOfBirth = new DateTime(1913, 05, 13),
        //        Bio = "If a film were made of the life of Vivien Leigh, it would open in India just before World War I, where a successful British businessman could live like a prince. In the mountains above Calcutta, a little princess is born. Because of the outbreak of World War I, she is six years old the first time her parents take her to England.",
        //        Sex = "Female"
        //    };

        //    var movieActor1 = new MovieActor() { Movie = movie, Actor = actor1 };
        //    var movieActor2 = new MovieActor() { Movie = movie, Actor = actor2 };
        //    var movieActor3 = new MovieActor() { Movie = movie, Actor = actor3 };

        //    movie.Producer = producer;
        //    movie.Actors = new List<MovieActor>();
        //    movie.Actors.Add(movieActor1);
        //    movie.Actors.Add(movieActor2);
        //    movie.Actors.Add(movieActor3);
        //var movie = new MovieDto
        //{
        //    MovieId = 11,
        //    Name = "Gone With the Wind",
        //    DateOfRelease = new DateTime(1940, 01, 17),
        //    Plot = "A manipulative woman and a roguish man conduct a turbulent romance during the American Civil War and Reconstruction periods."
        //};

        //var producer = new ProducerDto
        //{
        //    ProducerId = 10,
        //    Name = "David O. Selznick",
        //    Sex = "Male",
        //    DateOfBirth = new DateTime(1892, 09, 12),
        //    Bio = "David O. Selznick was a son of the silent movie producer Lewis J. Selznick. David studied at Columbia University until his father lost his fortune in the 1920s. David started work as an MGM script reader, shortly followed by becoming an assistant to Harry Rapf. He left MGM to work at Paramount then RKO."
        //};

        //var actor1 = new ActorDto
        //{
        //    ActorId = 22,
        //    MovieActorId = 0,
        //    Name = "Thomas Mitchell",
        //    DateOfBirth = new DateTime(1862, 07, 06),
        //    Bio = "Thomas Mitchell was one of the great American character actors, whose credits read like a list of the greatest films of the 20th century: Lost Horizon (1937); Stagecoach (1939); The Hunchback of Notre Dame (1939); Mr. Smith Goes to Washington (1939); Gone with the Wind (1939); It's a Wonderful Life (1946) and High Noon (1952).",
        //    Sex = "Male",
        //    Status = 0
        //};
        //var actor2 = new ActorDto
        //{
        //    ActorId = 2,
        //    MovieActorId = 25,
        //    Name = "Barbara O'Neil",
        //    DateOfBirth = new DateTime(1878, 11, 23),
        //    Bio = "Barbara O'Neil was born on July 17, 1910 in St. Louis, Missouri, USA. She was an actress, known for Gone with the Wind (1939), All This, and Heaven Too (1940) and Stella Dallas (1937). She was married to Joshua Logan. She died on September 3, 1980 in Cos Cob, Connecticut, USA.",
        //    Sex = "Female",
        //    Status = 1
        //};
        //var actor3 = new ActorDto
        //{
        //    ActorId = 25,
        //    MovieActorId = 26,
        //    Name = "Vivien Leigh",
        //    DateOfBirth = new DateTime(1913, 05, 13),
        //    Bio = "If a film were made of the life of Vivien Leigh, it would open in India just before World War I, where a successful British businessman could live like a prince. In the mountains above Calcutta, a little princess is born. Because of the outbreak of World War I, she is six years old the first time her parents take her to England.",
        //    Sex = "Female",
        //    Status = 2
        //};
        //movie.Producer = producer;
        //    movie.Actors = new List<ActorDto>();
        //    movie.Actors.Add(actor1);
        //    movie.Actors.Add(actor2);
        //    movie.Actors.Add(actor3);
        //}

        //public void CreateActor()
        //{
        //    var actor = new Actor
        //    {
        //        Name = "Marlon Brando",
        //        DateOfBirth = new DateTime(1924, 04, 03),
        //        Bio = "Marlon Brando is widely considered the greatest movie actor of all time, rivaled only by the more theatrically oriented Laurence Olivier in terms of esteem. Unlike Olivier, who preferred the stage to the screen, Brando concentrated his talents on movies after bidding the Broadway stage adieu in 1949.",
        //        Sex = "Male"
        //    };
        //}

        //public void CreateProducer()
        //{
        //    var producer = new Producer
        //    {
        //        Name = "Michael Bay",
        //        Sex = "Male",
        //        DateOfBirth = new DateTime(1965, 02, 17),
        //        Bio = "A graduate of Wesleyan University, Michael Bay spent his 20s working on advertisements and music videos. His first projects after film school were in the music video business."
        //    };

        //}




    }
}
