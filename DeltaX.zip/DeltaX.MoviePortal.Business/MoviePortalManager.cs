﻿using DeltaX.MoviePortal.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DeltaX.MoviePortal.Common.BusinessModels;
using DeltaX.MoviePortal.Common.Entities;
using DeltaX.MoviePortal.Common;

namespace DeltaX.MoviePortal.Business
{
    public class MoviePortalManager : IMoviePortalManager
    {
        private readonly IMoviePortalRepository _moviePortalRepository;
        public MoviePortalManager(IMoviePortalRepository movieRepository)
        {
            _moviePortalRepository = movieRepository ?? throw new ArgumentNullException("movieRepository");
        }

        public ActorDto CreateActor(ActorDto actor)
        {
            var result = _moviePortalRepository.CreateActor(AutoMapper.Mapper.Map<Actor>(actor));
            actor.ActorId = result.ActorId;
            return actor;
        }

        public MovieDto CreateMovie(MovieDto movie)
        {
            var movieEntity = Utility.MapMovie(movie);
            var result = _moviePortalRepository.CreateMovie(movieEntity);
            movie.MovieId = result.MovieId;
            return movie;
        }

        public ProducerDto CreateProducer(ProducerDto producer)
        {
            var result = _moviePortalRepository.CreateProducer(AutoMapper.Mapper.Map<Producer>(producer));
            producer.ProducerId = result.ProducerId;
            return producer;
        }

        public List<MovieListDto> GetAllMovies()
        {
            return _moviePortalRepository.GetAllMovies();
        }

        public MovieDto GetMovieById(int id)
        {
            return _moviePortalRepository.GetMovieById(id);
        }

        public List<ActorDto> SearchActors(string actorName)
        {
            return _moviePortalRepository.SearchActors(actorName);
        }

        public List<ProducerDto> SearchProducers(string producerName)
        {
            return _moviePortalRepository.SearchProducers(producerName);
        }

        public MovieDto UpdateMovie(MovieDto movie)
        {
            var movieEntity = Utility.MapMovie(movie);
            var result = _moviePortalRepository.UpdateMovie(movieEntity);
            return movie;
        }
    }
}
