﻿using DeltaX.MoviePortal.Common.BusinessModels;
using DeltaX.MoviePortal.Common.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeltaX.MoviePortal.Business
{
    public interface IMoviePortalManager
    {
        List<MovieListDto> GetAllMovies();
        List<ActorDto> SearchActors(string actorName);
        List<ProducerDto> SearchProducers(string producerName);
        MovieDto CreateMovie(MovieDto movie);
        ActorDto CreateActor(ActorDto actor);
        ProducerDto CreateProducer(ProducerDto producer);
        MovieDto GetMovieById(int id);
        MovieDto UpdateMovie(MovieDto movie);
    }
}
