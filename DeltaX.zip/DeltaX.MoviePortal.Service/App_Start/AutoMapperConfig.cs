﻿using AutoMapper;
using DeltaX.MoviePortal.Common.BusinessModels;
using DeltaX.MoviePortal.Common.Entities;
using DeltaX.MoviePortal.Web.Models;

namespace DeltaX.MoviePortal.Web.App_Start
{
    public class AutoMapperConfig : Profile
    {
        public AutoMapperConfig()
        {

        }
        public static void MapEntities()
        {
            Mapper.Initialize(config =>
            {
                config.AddProfile<AutoMapperConfig>();
                config.CreateMap<ActorDto, Actor>().ForMember(x => x.Movies, opt => opt.Ignore());
                config.CreateMap<MovieActor, ActorDto>().ForMember(x => x.Movies, opt => opt.Ignore());
                config.CreateMap<Actor, ActorDto>().ForMember(x => x.Movies, opt => opt.Ignore());
                config.CreateMap<MovieDto, Movie>().ForMember(x => x.Actors, opt => opt.Ignore());
                config.CreateMap<Movie, MovieDto>().ForMember(x => x.Actors, opt => opt.Ignore());
                config.CreateMap<ProducerDto, Producer>().ReverseMap();
                config.CreateMissingTypeMaps = true;
            });
        }
    }
}