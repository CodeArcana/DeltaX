﻿using DeltaX.MoviePortal.Business;
using DeltaX.MoviePortal.Common.BusinessModels;
using DeltaX.MoviePortal.Web.Models;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DeltaX.MoviePortal.Web.Controllers
{
    public class MoviePortalController : Controller
    {
        private readonly IMoviePortalManager _moviePortalManager;
        public MoviePortalController(IMoviePortalManager moviePortalManager)
        {
            _moviePortalManager = moviePortalManager;
        }

        // GET: MoviePortal
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult GetAllMovies()
        {
            return Json(_moviePortalManager.GetAllMovies(), JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetMovieById(int id)
        {
            var result = _moviePortalManager.GetMovieById(id);

            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public JsonResult SearchActors(string actorName)
        {
            var result = _moviePortalManager.SearchActors(actorName);
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        public JsonResult SearchProducers(string producerName)
        {
            return Json(_moviePortalManager.SearchProducers(producerName), JsonRequestBehavior.AllowGet);
        }
        public JsonResult CreateMovie(MovieDto movie, HttpPostedFileBase poster)
        {
            if(poster != null && poster.ContentLength > 0)
            {
                if (poster.ContentLength > 102400)
                {
                    ModelState.AddModelError("Poster", "The size of the file should not exceed 100 KB");
                    return null;
                }

                var supportedTypes = new[] { "jpg", "jpeg", "png" };

                var fileExt = System.IO.Path.GetExtension(poster.FileName).Substring(1);

                if (!supportedTypes.Contains(fileExt))
                {
                    ModelState.AddModelError("Poster", "Invalid type. Only jpg, jpeg and png types are supported.");
                    return null;
                }

                string posterName = System.IO.Path.GetFileName(poster.FileName);
                string physicalPath = Server.MapPath("~/Images/MoviePosters/" + posterName);
                movie.Poster = physicalPath;
            }
            

            return Json(_moviePortalManager.CreateMovie(movie), JsonRequestBehavior.AllowGet);
        }
        public JsonResult CreateActor(ActorDto actor)
        {
            return Json(_moviePortalManager.CreateActor(actor), JsonRequestBehavior.AllowGet);
        }
        public JsonResult CreateProducer(ProducerDto producer)
        {
            return Json(_moviePortalManager.CreateProducer(producer), JsonRequestBehavior.AllowGet);
        }
        public JsonResult UpdateMovie(MovieDto movie)
        {
            return Json(_moviePortalManager.UpdateMovie(movie), JsonRequestBehavior.AllowGet);
        }
    }
}