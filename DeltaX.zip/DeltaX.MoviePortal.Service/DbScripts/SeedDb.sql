﻿IF NOT EXISTS(SELECT * FROM Movie)
BEGIN
SET IDENTITY_INSERT [dbo].[Actor] ON 

INSERT [dbo].[Actor] ([ActorId], [Name], [Sex], [DateOfBirth], [Bio]) VALUES (1, N'Roy Scheider', N'Male', CAST(N'1932-08-12T00:00:00.0000000' AS DateTime2), N'Roy Richard Scheider (November 10, 1932 – February 10, 2008) was an American actor and amateur boxer')

INSERT [dbo].[Actor] ([ActorId], [Name], [Sex], [DateOfBirth], [Bio]) VALUES (2, N'Robert Shaw', N'Male', CAST(N'1927-03-09T00:00:00.0000000' AS DateTime2), N'Robert Archibald Shaw (9 August 1927 – 28 August 1978) was an English actor, novelist, and playwright.')

INSERT [dbo].[Actor] ([ActorId], [Name], [Sex], [DateOfBirth], [Bio]) VALUES (3, N'Dee Wallace', N'Female', CAST(N'1948-12-14T00:00:00.0000000' AS DateTime2), N'Deanna "Dee" Wallace (née Bowers; born December 14, 1948)[1], also known as Dee Wallace Stone, is an American actress. She is perhaps best known for her role as Mary, the mother, in the 1982 blockbuster film E.T. the Extra-Terrestrial.')

INSERT [dbo].[Actor] ([ActorId], [Name], [Sex], [DateOfBirth], [Bio]) VALUES (4, N'Peter Coyote', N'Male', CAST(N'1942-10-10T00:00:00.0000000' AS DateTime2), N'Peter Coyote (born Robert Peter Cohon; October 10, 1941)[1][3] is an American actor, author, director, screenwriter and narrator of films, theatre, television and audiobooks.')

INSERT [dbo].[Actor] ([ActorId], [Name], [Sex], [DateOfBirth], [Bio]) VALUES (5, N'Bruce Willis', N'Male', CAST(N'1945-03-12T00:00:00.0000000' AS DateTime2), N'Walter Bruce Willis (born March 19, 1955) is an American actor, producer, and singer. His career began on the Off-Broadway stage and then in television in the 1980s, most notably as David Addison in Moonlighting (1985–1989).')

INSERT [dbo].[Actor] ([ActorId], [Name], [Sex], [DateOfBirth], [Bio]) VALUES (6, N'Billy Bob Thornton', N'Male', CAST(N'1955-05-13T00:00:00.0000000' AS DateTime2), N'Billy Bob Thornton (born August 4, 1955) is an American actor, filmmaker, singer, songwriter, and musician.')

INSERT [dbo].[Actor] ([ActorId], [Name], [Sex], [DateOfBirth], [Bio]) VALUES (7, N'Liv Tyler', N'Female', CAST(N'1977-09-04T00:00:00.0000000' AS DateTime2), N'Liv Rundgren Tyler (born Liv Rundgren; July 1, 1977) is an American actress and former model.[2] She is the daughter of Aerosmith''s lead singer Steven Tyler, and model Bebe Buell.')

INSERT [dbo].[Actor] ([ActorId], [Name], [Sex], [DateOfBirth], [Bio]) VALUES (8, N'Whoopi Goldberg', N'Female', CAST(N'1955-02-04T00:00:00.0000000' AS DateTime2), N'Caryn Elaine Johnson (born November 13, 1955),[3] known professionally as Whoopi Goldberg (/ˈwʊpi/), is an American actress, comedian, author, and television host. She has been nominated for 13 Emmy Awards and is one of the few entertainers to have won an Emmy Award, a Grammy Award, an Academy Award, and a Tony Award. She was the second black woman to win an Academy Award for acting.')

INSERT [dbo].[Actor] ([ActorId], [Name], [Sex], [DateOfBirth], [Bio]) VALUES (9, N'Danny Glover', N'Male', CAST(N'1942-07-22T00:00:00.0000000' AS DateTime2), N'Danny Lebern Glover (born July 22, 1946) is an American actor, film director, and political activist. He is well known for his leading role as Roger Murtaugh in the Lethal Weapon film series, The Color Purple (1985), To Sleep with Anger (1990), Predator 2 (1990), and Angels in the Outfield (1994).')

INSERT [dbo].[Actor] ([ActorId], [Name], [Sex], [DateOfBirth], [Bio]) VALUES (10, N'Adolph Caesar', N'Male', CAST(N'1933-03-09T00:00:00.0000000' AS DateTime2), N'Adolph Caesar (December 5, 1933 – March 6, 1986) was an American actor, voice-over artist, theatre director, dancer, and choreographer. He was nominated for an Oscar and a Golden Globe for his supporting role in the film A Soldier''s Story (1984).')

INSERT [dbo].[Actor] ([ActorId], [Name], [Sex], [DateOfBirth], [Bio]) VALUES (11, N'Oprah Winfrey', N'Female', CAST(N'1954-01-29T00:00:00.0000000' AS DateTime2), N'Oprah Winfrey (born Orpah Gail Winfrey;[1] January 29, 1954) is an American media proprietor, talk show host, actress, producer, and philanthropist. She is best known for her talk show The Oprah Winfrey Show, which was the highest-rated television program of its kind in history and was nationally syndicated from 1986 to 2011 in Chicago, Illinois.[6] Dubbed the "Queen of All Media",[7] she was the richest African American of the 20th century.')

SET IDENTITY_INSERT [dbo].[Actor] OFF

SET IDENTITY_INSERT [dbo].[Producer] ON 

INSERT [dbo].[Producer] ([ProducerId], [Name], [Sex], [DateOfBirth], [Bio]) VALUES (1, N'Steven Spielberg', N'Male', CAST(N'1946-12-18T00:00:00.0000000' AS DateTime2), N'Steven Allan Spielberg KBE OMRI (born December 18, 1946) is an American filmmaker. He is considered one of the founding pioneers of the New Hollywood era and one of the most popular directors and producers in film history.[2]

After gaining traction in Hollywood with several minor theatrical releases, Spielberg gained notoriety through his work as the director for Jaws (1975), which was critically and commercially successful, and is considered the first summer blockbuster. His subsequent releases focused typically on science fiction and adventure films, with Close Encounters of the Third Kind (1977), the Indiana Jones series, E.T. the Extra-Terrestrial (1982), and the Jurassic Park series seen as archetypes of modern Hollywood escapist filmmaking. Spielberg transitioned into displaying humanistic issues in his later work, with The Color Purple (1985), Empire of the Sun (1987), Schindler''s List (1993), and Saving Private Ryan (1998) considered defining films of the 20th century. He has largely adhered to this outlook during the 21st century, with the critically acclaimed War Horse (2011), Bridge of Spies (2015), and The Post (2017).')

INSERT [dbo].[Producer] ([ProducerId], [Name], [Sex], [DateOfBirth], [Bio]) VALUES (2, N'Jerry Bruckheimer', N'Male', CAST(N'1943-09-12T00:00:00.0000000' AS DateTime2), N'Jerome Leon "Jerry" Bruckheimer (born September 21, 1943)[1][2] is an American film and television producer. He has been active in the genres of action, drama, fantasy and science fiction. His best known television series are CSI: Crime Scene Investigation, CSI: Miami, CSI: NY, Without a Trace, Cold Case, and the U.S. version of The Amazing Race. At one point, three of his TV series ranked among the top 10 in the U.S. ratings—a unique feat in television.')

INSERT [dbo].[Producer] ([ProducerId], [Name], [Sex], [DateOfBirth], [Bio]) VALUES (3, N'Kathleen Kennedy', N'Female', CAST(N'1953-06-05T00:00:00.0000000' AS DateTime2), N'Kathleen Kennedy (born June 5, 1953) is an American film producer. In 1981, she co-founded the production company Amblin Entertainment with Steven Spielberg and husband Frank Marshall.')

INSERT [dbo].[Producer] ([ProducerId], [Name], [Sex], [DateOfBirth], [Bio]) VALUES (4, N'David O. Selznick', N'Male', CAST(N'1892-09-12T00:00:00.0000000' AS DateTime2), N'David O. Selznick was a son of the silent movie producer Lewis J. Selznick. David studied at Columbia University until his father lost his fortune in the 1920s. David started work as an MGM script reader, shortly followed by becoming an assistant to Harry Rapf. He left MGM to work at Paramount then RKO.')

SET IDENTITY_INSERT [dbo].[Producer] OFF

SET IDENTITY_INSERT [dbo].[Movie] ON 

INSERT [dbo].[Movie] ([MovieId], [Name], [DateOfRelease], [Plot], [Poster], [ProducerId]) VALUES (1, N'Jaws', CAST(N'1975-09-12T00:00:00.0000000' AS DateTime2), N'During a beach party at dusk on Amity Island, a young woman, Chrissie Watkins, goes skinny dipping in the ocean. While treading water, she is violently pulled under. The next day, her partial remains are found on shore. The medical examiner''s ruling that the death was due to a shark attack leads police chief Martin Brody to close the beaches.', NULL, 1)

INSERT [dbo].[Movie] ([MovieId], [Name], [DateOfRelease], [Plot], [Poster], [ProducerId]) VALUES (2, N'E.T. the Extra-Terrestrial', CAST(N'1982-03-09T00:00:00.0000000' AS DateTime2), N'While visiting Earth in a California forest at night, a group of alien botanists land in a spacecraft. When government agents appear on the scene, the aliens flee in their spaceship, leaving one of their own behind in their haste. At a suburban home in the San Fernando Valley, a ten-year-old boy named Elliott is spending time with his brother, Michael, and his friends. As he returns from picking up a pizza, he discovers that something is hiding in their tool shed.', NULL, 1)

INSERT [dbo].[Movie] ([MovieId], [Name], [DateOfRelease], [Plot], [Poster], [ProducerId]) VALUES (3, N'Armageddon ', CAST(N'1998-05-13T00:00:00.0000000' AS DateTime2), N'A massive meteor shower destroys the orbiting Space Shuttle Atlantis and bombards a swath of land around the North Atlantic. NASA discovers through the Hubble Space Telescope that the meteors were debris propelled from the asteroid belt by a rogue asteroid roughly the size of Texas, christened "Dottie" by its discoverer. The asteroid will collide with Earth in 18 days, causing a second extinction event.', NULL, 2)

INSERT [dbo].[Movie] ([MovieId], [Name], [DateOfRelease], [Plot], [Poster], [ProducerId]) VALUES (4, N'The Color Purple', CAST(N'1985-03-03T00:00:00.0000000' AS DateTime2), N'Set in rural Georgia during the first forty years of the twentieth century, the film centers on the life of a fictional character named Celie, an oppressed black woman.', NULL, 3)

SET IDENTITY_INSERT [dbo].[Movie] OFF

SET IDENTITY_INSERT [dbo].[MovieActor] ON 

INSERT [dbo].[MovieActor] ([MovieActorId], [MovieId], [ActorId]) VALUES (1, 1, 1)

INSERT [dbo].[MovieActor] ([MovieActorId], [MovieId], [ActorId]) VALUES (2, 1, 2)

INSERT [dbo].[MovieActor] ([MovieActorId], [MovieId], [ActorId]) VALUES (3, 2, 3)

INSERT [dbo].[MovieActor] ([MovieActorId], [MovieId], [ActorId]) VALUES (4, 2, 4)

INSERT [dbo].[MovieActor] ([MovieActorId], [MovieId], [ActorId]) VALUES (5, 3, 5)

INSERT [dbo].[MovieActor] ([MovieActorId], [MovieId], [ActorId]) VALUES (6, 3, 6)

INSERT [dbo].[MovieActor] ([MovieActorId], [MovieId], [ActorId]) VALUES (7, 3, 7)

INSERT [dbo].[MovieActor] ([MovieActorId], [MovieId], [ActorId]) VALUES (8, 4, 8)

INSERT [dbo].[MovieActor] ([MovieActorId], [MovieId], [ActorId]) VALUES (9, 4, 9)

INSERT [dbo].[MovieActor] ([MovieActorId], [MovieId], [ActorId]) VALUES (10, 4, 10)

INSERT [dbo].[MovieActor] ([MovieActorId], [MovieId], [ActorId]) VALUES (11, 4, 11)

SET IDENTITY_INSERT [dbo].[MovieActor] OFF

END
