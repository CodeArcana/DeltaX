﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DeltaX.MoviePortal.Web.Models
{
    public class MovieViewModel
    {
        public int MovieId { get; set; }
        public string Name { get; set; }
        public DateTime DateOfRelease { get; set; }
        public string Plot { get; set; }
        public string Poster { get; set; }
        public ICollection<ActorViewModel> Actors { get; set; }
        public ProducerViewModel Producer { get; set; }
    }
}