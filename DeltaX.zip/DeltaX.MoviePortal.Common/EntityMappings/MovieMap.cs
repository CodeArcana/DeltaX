﻿using DeltaX.MoviePortal.Common.Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeltaX.MoviePortal.Common.EntityMappings
{
    public class MovieMap : EntityTypeConfiguration<Movie>
    {
        public MovieMap()
        {
            //Properties
            this.HasKey(t => t.MovieId);

            this.Property(t => t.Name)
                .IsRequired();

            this.Property(t => t.Poster)
               .IsOptional();

            this.Property(t => t.Plot)
                .IsOptional();

            this.Property(t => t.DateOfRelease)
                .IsRequired();            
            
            //Map to table
            this.ToTable("Movie");

            //Relationships
            this.HasRequired(m => m.Producer)
                .WithMany(p => p.Movies)
                .Map(t => t.MapKey("ProducerId"));

            this.HasMany(m => m.Actors)
                .WithRequired(m => m.Movie)
                .Map(t => t.MapKey("MovieId"));
        }
    }
}
