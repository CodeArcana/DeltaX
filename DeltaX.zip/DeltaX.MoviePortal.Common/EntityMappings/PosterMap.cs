﻿using DeltaX.MoviePortal.Common.Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeltaX.MoviePortal.Common.EntityMappings
{
    public class PosterMap : EntityTypeConfiguration<Poster>
    {
        public PosterMap()
        {
            //Properties
            this.HasKey(t => t.PosterId);

            //Map to table
            this.ToTable("Poster");
        }
    }
}
