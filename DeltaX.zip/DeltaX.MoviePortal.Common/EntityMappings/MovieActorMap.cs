﻿using DeltaX.MoviePortal.Common.Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeltaX.MoviePortal.Common.EntityMappings
{
    public class MovieActorMap : EntityTypeConfiguration<MovieActor>
    {
        public MovieActorMap()
        {
            //Properties
            this.HasKey(t => t.MovieActorId);
            this.Ignore(m => m.Status);//Dont map in db

            //Map to table
            this.ToTable("MovieActor");
        }
    }
}
