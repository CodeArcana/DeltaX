﻿using DeltaX.MoviePortal.Common.Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeltaX.MoviePortal.Common.EntityMappings
{
    public class ProducerMap : EntityTypeConfiguration<Producer>
    {
        public ProducerMap()
        {
            //Properties
            this.HasKey(t => t.ProducerId);

            this.Property(t => t.Name)
                .IsRequired();

            this.Property(t => t.DateOfBirth)
                .IsRequired();

            this.Property(t => t.Sex)
                .IsRequired();

            this.Property(t => t.Bio)
                .IsOptional();

            //Map to table
            this.ToTable("Producer");
        }
    }
}
