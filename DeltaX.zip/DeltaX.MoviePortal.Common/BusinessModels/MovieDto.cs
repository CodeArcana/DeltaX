﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeltaX.MoviePortal.Common.BusinessModels
{
    public class MovieDto
    {
        public int MovieId { get; set; }
        public string Name { get; set; }
        public DateTime DateOfRelease { get; set; }
        public string Plot { get; set; }
        public string Poster { get; set; }
        public List<ActorDto> Actors { get; set; }
        public ProducerDto Producer { get; set; }
    }
}
