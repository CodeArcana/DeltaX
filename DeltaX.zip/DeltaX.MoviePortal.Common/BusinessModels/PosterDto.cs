﻿namespace DeltaX.MoviePortal.Common.BusinessModels
{
    public class PosterDto
    {
        public int PosterId { get; set; }
        public byte[] Image { get; set; }
    }
}