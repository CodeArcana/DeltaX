﻿using System.Data.SqlClient;

namespace DeltaX.MoviePortal.Common
{
    internal class ServerConnection
    {
        private SqlConnection connection;

        public ServerConnection(SqlConnection connection)
        {
            this.connection = connection;
        }
    }
}