﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeltaX.MoviePortal.Common.Enums
{
    public enum StatusType
    {
        New = 0,
        Active = 1,
        Inactive = 2
    }
}
