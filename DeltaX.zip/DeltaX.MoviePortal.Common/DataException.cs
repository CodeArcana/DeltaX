﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DeltaX.MoviePortal.Common
{
    [Serializable()]
    public class DataException : System.Exception
    {
        public DataException(string message)
            : base(message)
        {

        }

        public DataException(string message, System.Exception inner)
            : base(message, inner)
        {

        }

        protected DataException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {

        }
    }
}
