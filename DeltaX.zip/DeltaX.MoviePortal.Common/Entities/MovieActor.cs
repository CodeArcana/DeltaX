﻿using DeltaX.MoviePortal.Common.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeltaX.MoviePortal.Common.Entities
{
    public class MovieActor
    {
        public int MovieActorId { get; set; }
        public virtual Movie Movie { get; set; }
        public virtual Actor Actor { get; set; }
        public StatusType? Status { get; set; }
    }
}
