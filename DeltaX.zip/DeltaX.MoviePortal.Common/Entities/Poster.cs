﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeltaX.MoviePortal.Common.Entities
{
    public class Poster
    {
        public int PosterId { get; set; }
        public byte[] Image { get; set; }
    }
}
