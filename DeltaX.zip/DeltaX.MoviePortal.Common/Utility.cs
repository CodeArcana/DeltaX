﻿using DeltaX.MoviePortal.Common.BusinessModels;
using DeltaX.MoviePortal.Common.Entities;
using DeltaX.MoviePortal.Common.Enums;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Reflection;

namespace DeltaX.MoviePortal.Common
{
    public static class Utility
    {
        private static string _connectionStringName = System.Configuration.ConfigurationManager.AppSettings["MoviePortalDbContextConnectionString"];
        private static string _connectionString = System.Configuration.ConfigurationManager.ConnectionStrings[_connectionStringName].ConnectionString;
        public static void SeedDatabase()
        {
            string filePath = Path.GetDirectoryName(System.AppDomain.CurrentDomain.BaseDirectory);

            filePath += @"\DbScripts\SeedDb.sql";

            var file = new FileInfo(filePath);
            var script = file.OpenText().ReadToEnd();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = connection;
                    cmd.CommandText = script;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static Movie MapMovie(MovieDto movie)
        {
            var movieEntity = AutoMapper.Mapper.Map<Movie>(movie);
            movieEntity.Actors = new List<MovieActor>();
            foreach (var actor in movie.Actors)
            {
                var movieActor = new MovieActor
                {
                    Actor = AutoMapper.Mapper.Map<Actor>(actor),
                    MovieActorId = actor.MovieActorId,
                    Status = (StatusType)actor.Status                    
                };

                movieEntity.Actors.Add(movieActor);
            }

            return movieEntity;
        }

        public static string GetConnectionString()
        {
            return _connectionString;
        }
        
    }
}
