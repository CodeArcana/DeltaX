﻿using DeltaX.MoviePortal.Common.Entities;
using DeltaX.MoviePortal.Common.EntityMappings;
using System;
using System.Configuration;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DeltaX.MoviePortal.Common;

namespace DeltaX.MoviePortal.DAL
{
    public class MoviePortalDbContext : DbContext
    {   
        public DbSet<Movie> Movies { get; set; }
        public DbSet<Producer> Producers { get; set; }
        public DbSet<Actor> Actors { get; set; }
        public DbSet<MovieActor> MovieActors { get; set; }

        static MoviePortalDbContext()
        {
            Database.SetInitializer<MoviePortalDbContext>(new CreateDatabaseIfNotExists<MoviePortalDbContext>());
            //Database.SetInitializer<MoviePortalDbContext>(null);
            Utility.SeedDatabase();
        }
        public MoviePortalDbContext()
            :base(Utility.GetConnectionString())
        {

        }
        public MoviePortalDbContext(string connectionString)
            : base(connectionString)
        {

        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Properties<DateTime>().Configure(c => c.HasColumnType("datetime2"));

            modelBuilder.Configurations.AddFromAssembly(typeof(MovieMap).Assembly);
        }
    }
}
