﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DeltaX.MoviePortal.Common.Entities;
using DeltaX.MoviePortal.Common.BusinessModels;
using DeltaX.MoviePortal.Common;
using DeltaX.MoviePortal.Common.Enums;

namespace DeltaX.MoviePortal.DAL
{
    public class MoviePortalRepository : IMoviePortalRepository
    {
        public MoviePortalRepository()
        {

        }
        public Actor CreateActor(Actor actor)
        {
            try
            {
                using (var context = new MoviePortalDbContext())
                {
                    if (context.Actors.FirstOrDefault(m => m.Name.Equals(actor.Name, StringComparison.OrdinalIgnoreCase) && m.DateOfBirth.Equals(actor.DateOfBirth)) != null)
                        throw new DataException("Actor already exists.");

                    context.Actors.Add(actor);
                    context.SaveChanges();
                }
                return actor;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public Movie CreateMovie(Movie movie)
        {
            try
            {
                using (var context = new MoviePortalDbContext())
                {
                    if (context.Movies.FirstOrDefault(m => m.Name.Equals(movie.Name, StringComparison.OrdinalIgnoreCase)) != null)
                        throw new DataException("Movie already exists.");

                    context.Movies.Add(movie);

                    foreach (var m in movie.Actors)
                    {
                        if(m.Actor.ActorId != 0)
                            context.Entry(m.Actor).State = System.Data.Entity.EntityState.Unchanged;
                    }

                    if (movie.Producer.ProducerId != 0)
                        context.Entry(movie.Producer).State = System.Data.Entity.EntityState.Unchanged;
                    
                    context.SaveChanges();
                }
                return movie;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public Producer CreateProducer(Producer producer)
        {
            try
            {
                using (var context = new MoviePortalDbContext())
                {
                    if (context.Producers.FirstOrDefault(m => m.Name.Equals(producer.Name, StringComparison.OrdinalIgnoreCase) && m.DateOfBirth.Equals(producer.DateOfBirth)) != null)
                        throw new DataException("Producer already exists.");

                    context.Producers.Add(producer);
                    context.SaveChanges();
                }
                return producer;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<MovieListDto> GetAllMovies()
        {
            try
            {
                using (var context = new MoviePortalDbContext())
                {
                    var result = context.Movies.Include("Producer").Include("Actors").Include("Actors.Actor").AsEnumerable().Select(a => new MovieListDto { MovieId = a.MovieId, Name = a.Name, Plot = a.Plot, YearOfRelease = a.DateOfRelease.Year, Producer = a.Producer.Name, Actors = string.Join(", ", a.Actors.Select<MovieActor, string>(m => m.Actor.Name)), Poster = a.Poster }).ToList();
                    return result;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public MovieDto GetMovieById(int id)
        {
            try
            {
                using (var context = new MoviePortalDbContext())
                {
                    var m = context.Movies.Include("Producer").Include("Actors").Include("Actors.Actor").AsEnumerable().Where(mv => mv.MovieId == id).FirstOrDefault();
                    var movie = new MovieDto
                    {
                        Actors = m.Actors.Select(a => new ActorDto { ActorId = a.Actor.ActorId, Name = a.Actor.Name, MovieActorId = a.MovieActorId }).ToList(),
                        DateOfRelease = m.DateOfRelease,
                        MovieId = m.MovieId,
                        Name = m.Name,
                        Plot = m.Plot,
                        Poster = m.Poster,
                        Producer = new ProducerDto { ProducerId = m.Producer.ProducerId, Name = m.Producer.Name }
                    };

                    return movie;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<ActorDto> SearchActors(string actorName)
        {
            try
            {
                using (var context = new MoviePortalDbContext())
                {
                    var result = context.Actors.Where(a => a.Name.Contains(actorName.Trim())).Select(a => new ActorDto { ActorId = a.ActorId, Name = a.Name }).OrderBy(a => a.Name.Length).ToList();
                    return result;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<ProducerDto> SearchProducers(string producerName)
        {
            try
            {
                using (var context = new MoviePortalDbContext())
                {
                    var result = context.Producers.Where(a => a.Name.Contains(producerName.Trim())).OrderBy(a => a.Name.Length).Select(p => new ProducerDto { Name = p.Name, ProducerId = p.ProducerId }).ToList();
                    return result;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public Movie UpdateMovie(Movie movie)
        {
            try
            {
                using (var context = new MoviePortalDbContext())
                {
                    context.Set<Movie>().Attach(movie);

                    var added = new List<MovieActor>();
                    var deleted = new List<MovieActor>();

                    foreach (var m in movie.Actors)
                    {
                        context.Set<MovieActor>().Attach(m);

                        if (m.Actor.ActorId != 0)
                            context.Entry(m.Actor).State = System.Data.Entity.EntityState.Unchanged;

                        if(m.Status.HasValue && m.Status.Value == StatusType.Inactive)
                        {
                            deleted.Add(m);
                            //context.Entry(m).State = System.Data.Entity.EntityState.Deleted;
                        }
                        else if(m.Status.Value == StatusType.New)
                        {
                            //context.Entry(m).State = System.Data.Entity.EntityState.Added;
                            added.Add(m);
                        }
                        else
                        {
                            context.Entry(m).State = System.Data.Entity.EntityState.Modified;

                            context.Entry(m).CurrentValues.SetValues(m);
                        }
                    }

                    if (movie.Producer.ProducerId != 0)
                        context.Entry(movie.Producer).State = System.Data.Entity.EntityState.Unchanged;

                    if (added.Any())
                        added.ForEach(a => 
                        {
                            context.Entry(a).State = System.Data.Entity.EntityState.Added;
                        });

                    if (deleted.Any())
                        deleted.ForEach(a =>
                        {
                            context.Entry(a).State = System.Data.Entity.EntityState.Deleted;
                        });

                    context.Entry(movie).CurrentValues.SetValues(movie);

                    context.SaveChanges();
                }
                return movie;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
