﻿using DeltaX.MoviePortal.Common.BusinessModels;
using DeltaX.MoviePortal.Common.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeltaX.MoviePortal.DAL
{
    public interface IMoviePortalRepository
    {
        List<MovieListDto> GetAllMovies();
        List<ActorDto> SearchActors(string actorName);
        List<ProducerDto> SearchProducers(string producerName);
        Movie CreateMovie(Movie movie);
        Actor CreateActor(Actor actor);
        Producer CreateProducer(Producer producer);
        MovieDto GetMovieById(int id);
        Movie UpdateMovie(Movie movie);
    }
}
